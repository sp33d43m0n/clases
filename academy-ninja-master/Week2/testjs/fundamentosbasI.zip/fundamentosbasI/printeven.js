function printUpTo(x) {
    console.log("1");
    for (let i = 2; i<=x; i+=2){
    console.log(i);
    }
}
 
 printUpTo(1000); // debería imprimir todos los pares de 1 to 1000
 