function printUpTo(x) {
    for (let i = 1; i<=x; i++){
    console.log(i);
  }
 }
 // debería imprimir todos los numeros del 1 al 255
  printUpTo(255); 